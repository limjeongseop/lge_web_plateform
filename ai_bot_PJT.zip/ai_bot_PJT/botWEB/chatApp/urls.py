from django.contrib import admin
from django.urls import path , include

from chatApp import views

urlpatterns = [
    # http://127.0.0.1:8000/chat/index
    path('index/'  , views.index  , name='index' ) ,
    path('train/'  , views.train  , name='train' ) ,
    path('answer/' , views.answer , name='answer' ) ,
]


