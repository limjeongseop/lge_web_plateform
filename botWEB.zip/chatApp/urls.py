from django.urls import path

from chatApp import views

urlpatterns = [
    path('home/',  views.home,   name="home"),
    path('train/', views.train,  name="train"),
    path('answer/', views.answer, name="answer"),
]

