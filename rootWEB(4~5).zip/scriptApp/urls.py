from django.urls import path , include
from scriptApp     import views

# http://localhost:8000/script
urlpatterns = [

    # http://localhost:8000/script/index/
    path('index/', views.index),

    # DOM
    # http://localhost:8000/script/script01/
    path('script01/', views.dom),

    # Chart
    # http://localhost:8000/script/script02/
    path('script02/', views.chart),

    # ajax
    # http://localhost:8000/script/ajax/
    path('ajax/', views.ajax),

    # modal
    # http://localhost:8000/script/modal/
    path('modal/', views.modal),

    path('modal_send/', views.modal_request , name = "modal_send") ,
]







