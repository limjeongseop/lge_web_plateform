
from django.contrib import admin
from django.urls import path , include
from htmlApp     import views


# http://localhost:8000/html
urlpatterns = [
    # http://localhost:8000/html/index/
    path('index/', views.index),
    # http://localhost:8000/html/html01/
    path('html01/', views.html01),

    # 레이아웃 추가
    # http://localhost:8000/html/layout/
    path('layout/', views.layout),

    # 테이블 추가
    # http://localhost:8000/html/table/
    path('table/', views.table),

    # 폼 추가
    # http://localhost:8000/html/form/
    path('form/', views.form),

    # radio 추가
    # http://localhost:8000/html/radio/
    path('radio/', views.radio , name='radio'),

    # select 추가
    # http://localhost:8000/html/select/
    path('select/', views.select , name='select'),
]






