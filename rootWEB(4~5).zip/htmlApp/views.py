from django.shortcuts import render

# Create your views here.

# 사용자 URL : http://localhost:8000/html/index - ioc callback function
def index(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/index")
    return render(request , 'html/index.html')

def html01(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/html01")
    return render(request, 'html/html01.html')

def layout(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/layout")
    return render(request, 'html/html02.html')

def table(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/table")
    # bussiness logic
    # rdbms(orm), csv -> DataFrame 형식으로 작업할 수 있음.....
    lst = [
        { 'name' : 'lge' , 'score' : 100 , 'url' : 'http://www.lge.co.kr'},
        { 'name' : 'cns' , 'score' : 90  , 'url' : 'http://www.lgcns.co.kr'}
    ]
    context = {'lists' : lst}
    return render(request, 'html/html03.html' , context)


def form(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/form")
    return render(request , 'html/html04.html')


def radio(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/radio")
    return render(request , 'html/html05.html')


def select(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/html/select")
    return render(request , 'html/html06.html')






